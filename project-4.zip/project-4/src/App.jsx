import { useState } from "react";
import FeedbackForm from "./components/FeedbackForm";
import FeedbackList from "./components/FeedbackList";
import "./index.css";

export default function App() {
  const [entries, setEntries] = useState([]);

  const handleAdd = (data) => {
    const item = { id: Date.now(), createdAt: new Date().toLocaleString(), ...data };
    setEntries((p) => [item, ...p]);
  };

  const handleRemove = (id) => {
    setEntries((p) => p.filter((e) => e.id !== id));
  };

  return (
    <div className="app-container">
      <h1 className="title">Customer Feedback & Issue Reporting</h1>

      <div className="layout">
        <div className="left-section">
          <FeedbackForm onSubmit={handleAdd} />
        </div>

        <div className="right-section">
          <h2 className="sub-title">Feedback Dashboard ({entries.length})</h2>
          <FeedbackList items={entries} onRemove={handleRemove} />
        </div>
      </div>
    </div>
  );
}
